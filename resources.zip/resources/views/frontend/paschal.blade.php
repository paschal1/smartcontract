<img src="{{ asset('frontend/images/about/08.png')}}" alt=""><!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Forexandbinarytrades</title>
        <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="{{ asset('css/custom.css') }}">

       
    </head>
    <body>

        <script src="{{ asset('js/bootstrap.min.js')}}" type="text/javascript"></script>
         <script src="{{ asset('js/popper.min.js')}}" type="text/javascript"></script>
         <script src="{{ asset('js/axios.min.js')}}" type="text/javascript"></script>
         <script src="{{ asset('js/custom.js')}}" type="text/javascript"></script>
         <script src="{{ asset('js/jquery-3.6.3.min.js')}}" type="text/javascript"></script>
         
    </body>
</html>
