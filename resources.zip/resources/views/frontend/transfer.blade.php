@extends('layouts.second')
@section('content')

<div class="card text-center">
  <div class="card-header">
    Secured
  </div>
  <div class="card-body">
    <h5 class="card-title">User to User Transfer</h5>
    <p class="card-text"><a href="">Account Balance:</a> $0</p>
     <label class="label">Receiver Email</label>
    <input type="text" class="form-control" id="inputPassword2" >
  <label class="label"></label>
   <label class="label">Amount Send</label>
    <input type="text" class="form-control" id="inputPassword2" >
   <div class="card-btn"> <a href="#" class="btn btn-success">Send</a> </div>
    
  </div>
  <div class="card-footer text-muted">
    
  </div>
</div>



                       
                    

@endsection